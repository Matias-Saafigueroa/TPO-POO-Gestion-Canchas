package interfaces;

import Clases.Cancha;
import java.util.List;

public interface IGestorCancha {
    void agregarCancha(Cancha cancha);
    boolean eliminarCancha(int id);
    Cancha buscarCancha(int id);
    List<Cancha> listarCanchas();
}

