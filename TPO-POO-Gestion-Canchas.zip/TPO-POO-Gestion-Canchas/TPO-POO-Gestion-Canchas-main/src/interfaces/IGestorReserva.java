package interfaces;

import Clases.Reserva;
import java.util.List;
import java.util.Optional;

public interface IGestorReserva {
    boolean crearReserva(Reserva reserva);
    boolean confirmarReserva(int id, boolean pagoRealizado);
    boolean cancelarReserva(int id);
    boolean validarReserva(int id);
    Optional<Reserva> mostrarReserva(int id);
    List<Reserva> historialReservas();
}
