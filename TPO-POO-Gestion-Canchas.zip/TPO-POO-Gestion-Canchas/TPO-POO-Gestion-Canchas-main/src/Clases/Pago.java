package Clases;

import java.time.LocalDate;

public abstract class Pago {
    private int idPago;
    private Reserva reserva;
    private LocalDate fechaPago;
    private double monto;

    public Pago(int idPago, Reserva reserva, LocalDate fechaPago, double monto) {
        this.idPago = idPago;
        this.reserva = reserva;
        this.fechaPago = fechaPago;
        this.monto = monto;
    }

    // Acción que realiza el pago (simulada)
    public abstract void procesarPago();

    public int getIdPago() {
        return idPago;
    }

    public Reserva getReserva() {
        return reserva;
    }

    public LocalDate getFechaPago() {
        return fechaPago;
    }

    public void setFechaPago(LocalDate fechaPago) {
        this.fechaPago = fechaPago;
    }

    public double getMonto() {
        return monto;
    }

    @Override
    public String toString() {
        return "Pago{" +
                "idPago=" + idPago +
                ", reservaId=" + (reserva != null ? reserva.getIdReserva() : "null") +
                ", fechaPago=" + fechaPago +
                ", monto=" + monto +
                '}';
    }
}
