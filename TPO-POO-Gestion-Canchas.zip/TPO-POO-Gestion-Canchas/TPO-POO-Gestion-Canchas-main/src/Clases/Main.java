package Clases;

import interfaces.*;
import java.util.*;

public class Main {

    private static final Scanner sc = new Scanner(System.in);
    private static final GestorCancha gestorCancha = new GestorCancha();
    private static final GestorReserva gestorReserva = new GestorReserva();
    private static final List<Cliente> clientes = new ArrayList<>();

    public static void main(String[] args) {
        while (true) {
            mostrarMenu();
            int opcion = leerEntero();
            switch (opcion) {
                case 1:
                    registrarCliente();
                    break;
                case 2:
                    registrarCancha();
                    break;
                case 3:
                    registrarReserva();
                    break;
                case 4:
                    listarCanchas();
                    break;
                case 5:
                    listarReservas();
                    break;
                case 0:
                    System.out.println("Saliendo...");
                    return;
                default:
                    System.out.println("Opción inválida");
            }
        }
    }

    private static void mostrarMenu() {
        System.out.println("========= MENÚ DE GESTIÓN DE CANCHAS =========");
        System.out.println("1. Registrar Cliente");
        System.out.println("2. Registrar Cancha");
        System.out.println("3. Registrar Reserva");
        System.out.println("4. Listar Canchas");
        System.out.println("5. Listar Reservas");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");
    }

    private static int leerEntero() {
        try {
            String line = sc.nextLine();
            return Integer.parseInt(line.trim());
        } catch (Exception e) {
            System.out.println("Entrada inválida. Intente nuevamente.");
            return -1;
        }
    }

    private static void registrarCancha() {
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        if (!gestorCancha.validarNombre(nombre)) {
            System.out.println("Nombre inválido");
            return;
        }
        int id = gestorCancha.asignarId();
        System.out.print("Superficie: ");
        String superficie = sc.nextLine();
        // Aquí podrías preguntar tipo y construir la subclase correspondiente
        Cancha c = new Cancha(id, TipoCancha.FUTBOL, superficie, nombre);
        gestorCancha.agregarCancha(c);
        System.out.println("Cancha registrada con id: " + id);
    }

    private static void listarCanchas() {
        List<Cancha> canchas = gestorCancha.listarCanchas();
        if (canchas.isEmpty()) {
            System.out.println("No hay canchas registradas.");
            return;
        }
        for (Cancha c : canchas) {
            System.out.println(c);
        }
    }

    private static void listarReservas() {
        List<Reserva> res = gestorReserva.historialReservas();
        if (res.isEmpty()) {
            System.out.println("No hay reservas.");
            return;
        }
        res.forEach(System.out::println);
    }

    private static void registrarCliente() {
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Apellido: ");
        String apellido = sc.nextLine();
        System.out.print("DNI: ");
        int dni = Integer.parseInt(sc.nextLine());
        Cliente cliente = new Cliente(nombre, apellido, dni);
        clientes.add(cliente);
        System.out.println("Cliente registrado.");
    }

    private static void registrarReserva() {
        // Simplificado: validar cliente y cancha y crear reserva
        System.out.println("Funcionalidad de reserva por implementar");
    }
}