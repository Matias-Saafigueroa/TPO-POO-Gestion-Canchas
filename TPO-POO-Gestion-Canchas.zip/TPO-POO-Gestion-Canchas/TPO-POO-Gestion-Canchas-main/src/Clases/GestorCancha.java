package Clases;

import interfaces.IGestorCancha;
import java.util.*;


public class GestorCancha implements IGestorCancha {

    private final Map<Integer, Cancha> canchas;
    private int nextId = 1;

    public GestorCancha() {
        this.canchas = new HashMap<>();
    }

    @Override
    public void agregarCancha(Cancha cancha) {
        if (cancha == null) throw new IllegalArgumentException("cancha no puede ser null");
        canchas.put(cancha.getIdCancha(), cancha);
    }

    @Override
    public boolean eliminarCancha(int id) {
        return canchas.remove(id) != null;
    }

    @Override
    public Cancha buscarCancha(int id) {
        return canchas.get(id);
    }

    @Override
    public List<Cancha> listarCanchas() {
        return new ArrayList<>(canchas.values());
    }

    // Utilitarios
    public int asignarId() {
        return nextId++;
    }

    public boolean validarNombre(String nombre) {
        return nombre != null && !nombre.trim().isEmpty() && nombre.length() >= 3;
    }
}
