package Clases;

import java.time.LocalDate;

public class PagoEfectivo extends Pago {
    private boolean abonadoEnCaja;

    public PagoEfectivo(int idPago, Reserva reserva, LocalDate fechaPago, double monto, boolean abonadoEnCaja) {
        super(idPago, reserva, fechaPago, monto);
        this.abonadoEnCaja = abonadoEnCaja;
    }

    @Override
    public void procesarPago() {
        System.out.println("Pago en efectivo procesado. Monto: $" + getMonto() + ". Abonado en caja: " + abonadoEnCaja);
    }

    public boolean isAbonadoEnCaja() {
        return abonadoEnCaja;
    }

    public void setAbonadoEnCaja(boolean abonadoEnCaja) {
        this.abonadoEnCaja = abonadoEnCaja;
    }
}
