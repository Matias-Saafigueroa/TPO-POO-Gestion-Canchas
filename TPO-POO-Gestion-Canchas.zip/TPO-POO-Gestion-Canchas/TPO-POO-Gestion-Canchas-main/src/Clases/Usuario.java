package Clases;

import java.io.Serializable;

public class Usuario implements Serializable {
    private String nombreUsuario;
    private String contrasena;
    private String rol;

    public Usuario(String nombreUsuario, String contrasena, String rol) {
        this.nombreUsuario = nombreUsuario;
        this.contrasena = contrasena;
        this.rol = rol;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public String getRol() {
        return rol;
    }

    @Override
    public String toString() {
        return String.format("Usuario: %s (rol: %s)", nombreUsuario, rol);
    }
}
