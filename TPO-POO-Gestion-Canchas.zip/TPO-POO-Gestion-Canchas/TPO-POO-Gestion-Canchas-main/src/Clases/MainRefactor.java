package Clases;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

public class MainRefactor {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GestorReserva gestorReserva = new GestorReserva();
        GestorCancha gestorCancha = new GestorCancha();

        System.out.println("Crear nueva reserva (demo).");
        System.out.print("Ingrese id de reserva (número): ");
        int idReserva = Integer.parseInt(scanner.nextLine());

        Cliente clienteDemo = null;
        Cancha canchaDemo = null;

        System.out.print("Ingrese monto total de la reserva: ");
        double precio = Double.parseDouble(scanner.nextLine());


        Reserva nuevaReserva = new Reserva(idReserva, clienteDemo, canchaDemo,
                LocalDate.now(), LocalTime.of(18, 0), LocalTime.of(19, 0),
                precio, null, EstadoReserva.PENDIENTE);

        System.out.println("¿Cómo desea pagar? (1-Tarjeta, 2-Efectivo)");
        int opcionPago = Integer.parseInt(scanner.nextLine());

        Pago pagoDeLaReserva;
        int idPago = idReserva * 10;
        if (opcionPago == 1) {
            System.out.println("Procesando pago con tarjeta...");
            System.out.print("Número de tarjeta: ");
            String numero = scanner.nextLine();
            System.out.print("Cuotas (ej: 1): ");
            int cuotas = Integer.parseInt(scanner.nextLine());
            System.out.print("Entidad bancaria: ");
            String entidad = scanner.nextLine();

            pagoDeLaReserva = new PagoTarjeta(idPago, nuevaReserva, LocalDate.now(), precio,
                    numero, cuotas, entidad);

        } else {
            System.out.println("Procesando pago en efectivo...");
            System.out.print("¿Abonado en caja? (true/false): ");
            boolean abonado = Boolean.parseBoolean(scanner.nextLine());

            pagoDeLaReserva = new PagoEfectivo(idPago, nuevaReserva, LocalDate.now(), precio, abonado);
        }


        nuevaReserva.setPago(pagoDeLaReserva);
        pagoDeLaReserva.procesarPago();


        boolean confirmado = gestorReserva.confirmarReserva(nuevaReserva.getIdReserva(), true);
        System.out.println("Reserva confirmada? " + confirmado);

        scanner.close();
    }
}
