package Clases;

import java.time.LocalDate;
import java.time.LocalTime;

public class Reserva {
    private int idReserva;
    private Cliente cliente;
    private Cancha cancha;
    private LocalDate fecha;
    private LocalTime horaInicio;
    private LocalTime horaFin;
    private double montoTotal;
    private Pago pago;
    private EstadoReserva estado;

    public Reserva(int idReserva, Cliente cliente, Cancha cancha,
                   LocalDate fecha, LocalTime horaInicio, LocalTime horaFin,
                   double montoTotal, Pago pago, EstadoReserva estado) {
        this.idReserva = idReserva;
        this.cliente = cliente;
        this.cancha = cancha;
        this.fecha = fecha;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.montoTotal = montoTotal;
        this.pago = pago;
        this.estado = estado;
    }

    public int getIdReserva() {
        return idReserva;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Cancha getCancha() {
        return cancha;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public LocalTime getHoraInicio() {
        return horaInicio;
    }

    public LocalTime getHoraFin() {
        return horaFin;
    }

    public double getMontoTotal() {
        return montoTotal;
    }

    public Pago getPago() {
        return pago;
    }

    public void setPago(Pago pago) {
        this.pago = pago;
    }

    public EstadoReserva getEstado() {
        return estado;
    }

    public void setEstado(EstadoReserva estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Reserva{" +
                "idReserva=" + idReserva +
                ", cliente=" + (cliente != null ? cliente.getNombre() : "null") +
                ", cancha=" + (cancha != null ? cancha.getNombre() : "null") +
                ", fecha=" + fecha +
                ", horaInicio=" + horaInicio +
                ", horaFin=" + horaFin +
                ", montoTotal=" + montoTotal +
                ", pago=" + (pago != null ? pago.toString() : "null") +
                ", estado=" + estado +
                '}';
    }
}
