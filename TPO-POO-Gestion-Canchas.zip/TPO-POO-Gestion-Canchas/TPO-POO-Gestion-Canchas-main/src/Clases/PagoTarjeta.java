package Clases;

import java.time.LocalDate;

public class PagoTarjeta extends Pago {
    private String numeroTarjeta;
    private int cuotas;
    private String entidadBancaria;

    public PagoTarjeta(int idPago, Reserva reserva, LocalDate fechaPago, double monto,
                       String numeroTarjeta, int cuotas, String entidadBancaria) {
        super(idPago, reserva, fechaPago, monto);
        this.numeroTarjeta = numeroTarjeta;
        this.cuotas = cuotas;
        this.entidadBancaria = entidadBancaria;
    }

    @Override
    public void procesarPago() {
        // Simulación: validar formato mínimo
        if (numeroTarjeta == null || numeroTarjeta.length() < 12) {
            System.out.println("Número de tarjeta inválido. Pago no procesado.");
            return;
        }
        // Mostrar sólo 4 primeros y 4 últimos (o 4 primeros + mask)
        String masked = numeroTarjeta.length() > 8
                ? numeroTarjeta.substring(0, 4) + "****" + numeroTarjeta.substring(numeroTarjeta.length()-4)
                : "****";
        System.out.println("Pago con tarjeta procesado. Tarjeta: " + masked + ", monto: $" + getMonto());
        // Aquí podrías cambiar el estado de la reserva a PAGADA / CONFIRMADA si corresponde.
    }

    // getters/setters si querés
}
