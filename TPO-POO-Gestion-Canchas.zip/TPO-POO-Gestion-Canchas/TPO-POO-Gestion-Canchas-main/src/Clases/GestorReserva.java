package Clases;

import interfaces.IGestorReserva;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

public class GestorReserva implements IGestorReserva {

    private static final Path RUTA_ARCHIVO_RESERVAS = Paths.get("data", "reservas.txt"); // directorio data/
    private final List<Reserva> reservasCache = new ArrayList<>();

    public GestorReserva() {
        // intentar cargar al iniciar (opcional)
        try {
            if (Files.exists(RUTA_ARCHIVO_RESERVAS)) {
                List<String> lines = Files.readAllLines(RUTA_ARCHIVO_RESERVAS);
                for (String l : lines) {
                    Reserva r = Reserva.fromCsv(l);
                    if (r != null) reservasCache.add(r);
                }
            } else {
                Files.createDirectories(RUTA_ARCHIVO_RESERVAS.getParent());
                Files.createFile(RUTA_ARCHIVO_RESERVAS);
            }
        } catch (IOException e) {
            System.err.println("No se pudo inicializar GestorReserva: " + e.getMessage());
        }
    }

    @Override
    public synchronized boolean crearReserva(Reserva reserva) {
        if (reserva == null) return false;
        reservasCache.add(reserva);
        return persistirTodas();
    }

    @Override
    public synchronized boolean confirmarReserva(int id, boolean pagoRealizado) {
        if (!pagoRealizado) return false;
        Optional<Reserva> opt = reservasCache.stream().filter(r -> r.getId() == id).findFirst();
        if (opt.isPresent()) {
            Reserva r = opt.get();
            r.setEstado(EstadoReserva.CONFIRMADA);
            return persistirTodas();
        }
        return false;
    }

    @Override
    public synchronized boolean cancelarReserva(int id) {
        boolean removed = reservasCache.removeIf(r -> r.getId() == id);
        if (removed) return persistirTodas();
        return false;
    }

    @Override
    public boolean validarReserva(int id) {
        return reservasCache.stream().anyMatch(r -> r.getId() == id);
    }

    @Override
    public Optional<Reserva> mostrarReserva(int id) {
        return reservasCache.stream().filter(r -> r.getId() == id).findFirst();
    }

    @Override
    public List<Reserva> historialReservas() {
        return new ArrayList<>(reservasCache);
    }

    private boolean persistirTodas() {
        try {
            List<String> lines = reservasCache.stream().map(Reserva::toCsv).collect(Collectors.toList());
            Files.write(RUTA_ARCHIVO_RESERVAS, lines, StandardOpenOption.TRUNCATE_EXISTING);
            return true;
        } catch (IOException e) {
            System.err.println("Error al guardar reservas: " + e.getMessage());
            return false;
        }
    }
}
