package Clases;

import java.io.*;
import java.util.*;

public class GestorRegistro {
    private static final String RUTA_USUARIOS = "data/usuarios.txt";
    private Map<String, Usuario> usuarios = new HashMap<>();

    public GestorRegistro() {
        cargarUsuarios();
    }

    private void cargarUsuarios() {
        File archivo = new File(RUTA_USUARIOS);
        if (!archivo.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(";");
                if (partes.length == 3) {
                    usuarios.put(partes[0], new Usuario(partes[0], partes[1], partes[2]));
                }
            }
        } catch (IOException e) {
            System.err.println("Error cargando usuarios: " + e.getMessage());
        }
    }

    public boolean registrarUsuario(String nombre, String contrasena, String rol) {
        if (usuarios.containsKey(nombre)) {
            System.out.println("El usuario ya existe.");
            return false;
        }
        Usuario nuevo = new Usuario(nombre, contrasena, rol);
        usuarios.put(nombre, nuevo);
        guardarUsuarios();
        System.out.println("Usuario registrado con éxito.");
        return true;
    }

    public Usuario login(String nombre, String contrasena) {
        Usuario u = usuarios.get(nombre);
        if (u != null && u.getContrasena().equals(contrasena)) {
            System.out.println("Inicio de sesión exitoso: " + u);
            return u;
        }
        System.out.println("Usuario o contraseña incorrectos.");
        return null;
    }

    private void guardarUsuarios() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(RUTA_USUARIOS))) {
            for (Usuario u : usuarios.values()) {
                bw.write(u.getNombreUsuario() + ";" + u.getContrasena() + ";" + u.getRol());
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error guardando usuarios: " + e.getMessage());
        }
    }

    public void listarUsuarios() {
        if (usuarios.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
            return;
        }
        usuarios.values().forEach(System.out::println);
    }
}
